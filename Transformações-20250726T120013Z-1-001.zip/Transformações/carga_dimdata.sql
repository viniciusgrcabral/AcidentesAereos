SET SESSION cte_max_recursion_depth = 10000;

USE md_dados_dw;

SET @dt_inicio = '2010-01-01';
SET @dt_fim = CURDATE(); 

SET lc_time_names = 'pt_BR';


INSERT INTO dimData (
    idData,
    dataCompleta,
    ano,
    trimestre,
    mes,
    dia,
    diaSemana,
    nomeDiaSemana,
    nomeMes,
    diaUtil
)
WITH RECURSIVE date_range AS (
    SELECT @dt_inicio AS full_date
    UNION ALL
    SELECT full_date + INTERVAL 1 DAY
    FROM date_range
    WHERE full_date < @dt_fim
)
SELECT
    YEAR(full_date) * 10000 + MONTH(full_date) * 100 + DAY(full_date), 
    full_date,
    YEAR(full_date), 
    QUARTER(full_date), 
    MONTH(full_date), 
    DAY(full_date),
    DAYOFWEEK(full_date),
    DAYNAME(full_date), 
    MONTHNAME(full_date),
    CASE WHEN DAYOFWEEK(full_date) IN (1, 7) THEN 0 ELSE 1 END 
FROM
    date_range;